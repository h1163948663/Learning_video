from django.apps import AppConfig


class VideosConfig(AppConfig):
    name = 'videos'
