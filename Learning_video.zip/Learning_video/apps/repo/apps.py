from django.apps import AppConfig


class PathsConfig(AppConfig):
    name = 'paths'
